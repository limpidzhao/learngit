/*
 * Copyright Adam Pritchard 2013
 * MIT License : http://adampritchard.mit-license.org/
 */

mocha.setup('bdd');
var expect = chai.expect;